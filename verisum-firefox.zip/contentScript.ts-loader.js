(function () {
  'use strict';

  const injectTime = performance.now();
  (async () => {
    const { onExecute } = await import(
      /* @vite-ignore */
      getExtensionResourceUrl("contentScript.ts.js")
    );
    onExecute?.({ perf: { injectTime, loadTime: performance.now() - injectTime } });
  })().catch(console.error);
  function getExtensionResourceUrl(path) {
    return `chrome-extension://${chrome.runtime.id}/${path}`;
  }

})();
